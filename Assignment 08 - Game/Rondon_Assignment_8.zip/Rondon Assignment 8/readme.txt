This is game called "Cluck Crush!".

Originally, I imagined a game where rectangular blocks would fall from the sky at varied speeds.
A small square representing the player would have to move left/right across the screen to avoid
the falling blocks. The score would be calculated in seconds, with each second the player
managed to avoid the falling blocks being added to their score. Once a block smooshed the player,
by overlapping the rectangle on the square, the game would be over.

Once I built the basic functionality in using the blocks and the square, I was able to use loadImage
to improve the aesthetics of the game. The blocks become chickens and the square became grandma.

If I had more time to improve the game I would like to find a way to create levels. So if a player
survived for 60 seconds they could move on to the next level where the chickens fell at a faster, more
frequent pace. I would also like to find away to track and hold the score. So that players could see if
they improve over time.

INSTRUCTIONS
Playing Cluck Crush is simple. 
Move grandma left and right across the screen, using the left arrow and right arrow, to avoid the 
falling chickens. 
As the time passes, each second you keep grandma from being crushed by a chicken gets added to your score. 
But be careful, as the time passes more chickens fall from the sky!
Once grandma is crushed by a chicken the game is over. 
See how many points you can get!
To restart the game, hit Enter. 
